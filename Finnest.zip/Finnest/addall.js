// Import required modules
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

// Create an instance of Express app
const app = express();

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Parse incoming requests with URL-encoded payloads
app.use(bodyParser.urlencoded({ extended: true }));

// MongoDB connection URI
const dbURI = 'mongodb://localhost:27017/BankAll';

// Connect to MongoDB
mongoose
  .connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('Error connecting to MongoDB:', err));


// Create a schema for savings and investments
const transactionSchema = new mongoose.Schema({
  type: { type: String, required: true },
  amount: { type: Number, required: true },
  interest: { type: Number, required: true },
  date: { type: Date, default: Date.now },
});

// Create a schema for Bank Schema
const bankSchema = new mongoose.Schema({
bankname: { type: String, required: true },
acctnumber: { type: String, required: true }, 
savings: [transactionSchema],
investments: [transactionSchema],  
balance: { type: Number},
});


// Create a schema for customers
const customerSchema = new mongoose.Schema({
  custid: { type: String, required: true },
  name: { type: String, required: true },  
  bank: [bankSchema],
  
});

// Create a schema for Users
const userSchema = new mongoose.Schema({
  userid: { type: String, required: true },
  pwd: { type: String, required: true },
  custid: { type: String, required: true },
  name: { type: String, required: true },
  address: { type: String, required: true },
  phone: { type: Number, required: true },
  emailid: { type: String, required: true },
});


// Create a model for Users
const User = mongoose.model('User', userSchema);

const users = [
    
    { userid: 'arun', 
     pwd:'2222',
     custid:'2222',
     name:'Arun Mozhi',
     address: 'No.100 , DB Road, RS Puram, Coimbatore - 641010' ,
     phone:'9797772221',
     emailid:'classic@gmail.com'
    },
     
       
  /*
  {  userid: '', 
     pwd:'',
     custid:'',
     name:'',
     address: '' ,
     phone:'',
     emailid:''
    }
    */
  // Add more sample user data here...
];

// Save sample Users to MongoDB
users.forEach((user) => {
  const newUser = new User(user);
  newUser.save();
});

// Create a model for customers
const Customer = mongoose.model('Customer', customerSchema);

// Sample bank customers with initial balance (replace this with your real customer data)
const customers = [
     {  custid:'5555',
 name:'Ponniyin Selvan',
  bank: [ {
bankname: 'HDFC Bank',
acctnumber:  '353535' , 
savings: [{type: 'Regular Savings',amount:3000 , interest:90,date: '' }],
investments: [{type:'Corporate Deposit',amount:1000 , interest:75, date:''},
              {type: 'Long-Term Investment',amount:5000 , interest:350,date: '' }],  
balance:9515 }  ,
       {
bankname: 'Yes Bank',
acctnumber:  '151515' , 
savings: [{type: 'Regular Savings',amount:6000 , interest:180,date: '' }],
investments: [{type:'Short-Term Investment',amount:1000 , interest:60, date:''}],  
balance: 7240 } ,       
        
        {
bankname: 'Axis Bank',
acctnumber:  '101010' , 
savings: [{type: 'Regular Savings',amount:3000 , interest:90,date: '' }],
investments: [{type:'Short-Term Investment',amount:3500 , interest:262, date:''}],  
balance: 6352 }
        ],
     }
        
    // Add more sample customer data here...
];

// Save sample customers to MongoDB
customers.forEach((customer) => {
  const newCustomer = new Customer(customer);
  newCustomer.save();
});

// Start the server
const port = 5000;
app.listen(port, () => {
  console.log(`Server started on http://localhost:${port}`);
});