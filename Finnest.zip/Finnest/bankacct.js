// Import required modules
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const session = require('express-session');
const bcrypt = require('bcrypt');
// Create an instance of Express app
const app = express();

// Set EJS as the view engine
app.set('view engine', 'ejs');

app.use(express.static('public'));
app.use('/pic', express.static('images'));

// Parse incoming requests with URL-encoded payloads
app.use(bodyParser.urlencoded({ extended: true }));

var favicon = require('serve-favicon');

// Set up express-session for session management
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: false,
}));

// MongoDB connection URI
const dbURI = 'mongodb://localhost:27017/Finn';

// Connect to MongoDB
mongoose
  .connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('Error connecting to MongoDB:', err));


// Create a schema for savings and investments
const transactionSchema = new mongoose.Schema({
  type: { type: String, required: true },
  amount: { type: Number, required: true },
  interest: { type: Number, required: true },
  date: { type: Date, default: Date.now },
});

// Create a schema for Bank Schema
const bankSchema = new mongoose.Schema({
bankname: { type: String, required: true },
acctnumber: { type: String, required: true }, 
savings: [transactionSchema],
investments: [transactionSchema],  
balance: { type: Number},
});

// Create a schema for customers
const customerSchema = new mongoose.Schema({
  custid: { type: String, required: true },
  name: { type: String, required: true },  
  bank: [bankSchema],
  
});

// Create a schema for Users
const userSchema = new mongoose.Schema({
  username: { type: String, required: true,unique: true },
  password: { type: String, required: true },
  custid: { type: String, required: true },
  name: { type: String, required: true },
  address: { type: String, required: true },
  phone: { type: String, required: true },
  emailid: { type: String, required: true },
});


// Create a model for Users
const User = mongoose.model('User', userSchema);

// Create a model for customers
const Customer = mongoose.model('Customer', customerSchema);

// Sample products for savings and investments
const products = [
  { name: 'Regular Savings', interestRate: 0.02, liquidity: 'High' },
  { name: 'Fixed Deposit', interestRate: 0.07, liquidity: 'Medium'},
  { name: 'Public Provident Fund (PPF)', interestRate: 0.075, liquidity: 'Low' },
  { name: 'Sukanya Samridi Account', interestRate: 0.075, liquidity: 'Low'  },
  { name: 'Long-Term Investment', interestRate: 0.05, liquidity: 'Low'  },
  { name: 'Short-Term Investment', interestRate: 0.03, liquidity: 'High' },
  { name: 'Corporate Deposit', interestRate: 0.065, liquidity: 'Medium'  },
  { name: 'Employee Provident Fund (EPF)', interestRate: 0.0815, liquidity: 'Low'  },
  { name: 'National Savings Certificate (NSC)', interestRate: 0.0725, liquidity: 'Low'  },
  { name: 'Bonds', interestRate: 0.03, liquidity: 'Low'  },
  { name: 'Unit Linked Insurance Plans (ULIPs)', interestRate: 0.055, liquidity: 'Low'  }    
    
];

              
const investmentOptions = [
  {
    name: "Stocks",
    definition: "Stocks represent ownership shares in a company. When you buy a stock, you become a partial owner of the company, and your returns are based on the company's performance and stock price appreciation. Stocks have the potential for high returns but also come with higher risks."
  },
  {
    name: "Bonds",
    definition: "Bonds are debt securities issued by governments or corporations. When you buy a bond, you are essentially lending money to the issuer in exchange for periodic interest payments (coupon) and the return of the principal amount at maturity. Bonds are generally considered less risky than stocks but offer lower potential returns."
  },
  {
    name: "Mutual Funds",
    definition: "Mutual funds pool money from multiple investors to invest in a diversified portfolio of stocks, bonds, or other securities. Professional fund managers manage the investments, making it an accessible option for individuals with limited investment knowledge. Mutual funds can vary in risk depending on their asset allocation."
  },
  {
    name: "Systematic Investment Plans",
    definition: "A SIP is a systematic approach to investing and involves allocating a small pre-determined amount of money for investment in the market at regular intervals (usually every month). The SIP route is the preferred way of investing in stocks and Mutual Funds because it allows you to participate in the market while managing risk better."
  },
  {
    name: "Exchange-Traded Funds (ETFs)",
    definition: "ETFs are similar to mutual funds but are traded on stock exchanges like individual stocks. They offer diversification and can track various indices, sectors, or asset classes. ETFs provide liquidity and are a popular choice for investors looking for a more flexible investment option."
  },
  {
    name: "Real Estate",
    definition: "Investing in real estate involves purchasing properties for rental income or capital appreciation. Real estate can offer steady cash flow and act as a hedge against inflation, but it requires active management and may involve significant upfront costs."
  },
  {
    name: "Certificate of Deposit (CD)",
    definition: "A CD is a time deposit offered by banks with fixed terms and interest rates. Investors deposit a specific amount for a predetermined period, and upon maturity, they receive the principal and interest earned. CDs are considered safe but offer lower returns compared to other investments."
  },
  {
    name: "Commodities",
    definition: "Commodities include physical goods like gold, silver, oil, agricultural products, etc. Investors can buy commodities directly or invest through commodity futures contracts. Commodities can provide diversification benefits and act as a hedge against inflation."
  },
  {
    name: "Cryptocurrencies",
    definition: "Cryptocurrencies are digital or virtual currencies that use cryptography for security. Bitcoin and Ethereum are well-known examples. Cryptocurrencies have gained popularity for their potential high returns, but they are highly volatile and speculative."
  },

  {
    name: "Peer-to-Peer Lending",
    definition: "In peer-to-peer lending, individuals lend money to borrowers through online platforms, bypassing traditional financial institutions. Investors earn interest on their loans, and borrowers get access to funds at potentially lower rates than traditional loans."
  }
];


// Go to Home Page
app.get('/', async (req, res) => {
  res.render('main');
});

// Route to display the sign-up form
app.get('/signup', (req, res) => {
  res.render('signup');
});

/*
// Route to handle sign-up form submission
app.post('/signup', async (req, res) => {
  try {
    const { name, password,address,phone,emailid } = req.body;
      
      if(phone.length<10){
           phone="0000".concat(phone);
      }
   
    const username1 = name.slice(0,4).concat(phone.slice((phone.length-4), (phone.length-4)+4));
   let custid = username1;
      
      // Hash the password before storing it in the database
    const hashedPassword = await bcrypt.hash(password, 10);
 console.log(username1,name, password,custid,address,phone,emailid);
    // Create a new user in the database
      
      const user = await User.findById(username1);

  if (user) {
    return res.status(404).send('User Name already exist, please try giving alternate name');
  }
      
  //  await User.create({ username1, password: hashedPassword,custid,name,address,phone,emailid });
      user.username = username1;
      user.password=hashedPassword;
      user.custid = custid;
      user.name =  name;
      user.address = address;
      user.phone =phone;
      user.emailid= emailid;
      
    await user.save();
    res.redirect('/login');
  } catch (err) {
    res.status(500).send('Error signing up. Please try again later...');
  }
});
*/


// Route to handle the signup form submission
app.post('/signup', async (req, res) => {
  try {
    const { username, name, password, custid, address, phone, emailid } = req.body;

    // Check if the username already exists in the database
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).send('Username already exists. Please choose a different username.');
    }

    // Create a new user in the database
     await User.create({ username, name, password, custid, address, phone, emailid });
     await Customer.create({custid,name});
    res.redirect('/login');
  } catch (err) {
    res.status(500).send('Error signing up. Please try again later.');
  }
});


// Route to display the sign-in form
app.get('/login', (req, res) => {
  res.render('login');
});

// Route to handle sign-in form submission
app.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
     
    // Find the user in the database by their username
    let user = await User.findOne({ username });

    if (!user) {
      return res.status(401).send('Invalid username or password.');
    }

    
    if (!password) {
      return res.status(401).send('Invalid username or password.');
    }
    // Set a session variable to indicate that the user is logged in
    req.session.isLoggedIn = true;
    req.session.username = user.username;
    let custid= user.custid;
    let customer = await Customer.find({ custid:custid });
    console.log("Login as " + custid );
    console.log("Customer : " + customer , customer.id );
    console.log( "User : " + user);
      
      const allCustomers = await Customer.find({custid:custid});
 res.render('customerList', { customers: allCustomers });
      
 // res.render('custData',  { customer: allCustomers , user, products, investmentOptions}  );
   //  res.redirect('/add/customer');  // Go to Customer list;
  } catch (err) {
    res.status(500).send('Error logging in. Please try again later.');
  }
});

// Middleware to protect routes that require authentication
function requireLogin(req, res, next) {
  if (req.session.isLoggedIn) {
    next();
  } else {
    res.redirect('/login');
  }
}

/*
// Route to display the list of customers. It renders customerList.ejs
app.get('/customers', async (req, res) => {
  const allCustomers = await Customer.find({});
  res.render('customerList', { customers: allCustomers });
});
*/


// Route to display the list of customers. It renders customerList.ejs
app.get('/customers', async (req, res) => {
  const allCustomers = await Customer.find({});
  res.render('customerList', { customers: allCustomers });
});

// Route to display customer details and savings/investment options based on ID
app.get('/customers/:id', async (req, res) => {
    
   //  res.setHeader("Content-Type", "text/html");
  const customerId = req.params.id;
  const customer = await Customer.findById(customerId);

  if (!customer) {
    return res.status(404).send('Customer not found');
     // return res.status(404).json('Customer not found');
  }
   else { 
  const custid =  (customer.custid).toString();
  console.log("custid = " + custid);

  const user2 = await User.find({});    
    
       if (!user2) {
    return res.status(404).json({ error: "No User Found" });
    }
       else {
        user2.forEach((user) => {
    
        console.log("(user.custid).toString() = " + (user.custid).toString());
      
        console.log("Users : " + user);
      
        if((user.custid).toString() === custid)
        {
            console.log("Inside custid = " + custid);
          return res.render('custData', { customer, products , user, investmentOptions});
            //return res.json(user2);
        }
    });        
           
 }
   
}
// res.render('custDetails', { customer, products});     
});


// Route to handle savings and investment form submission
app.post('/customers/:id/save-invest', async (req, res) => {
  const customerId = req.params.id;
  const productIds = req.body.products;
      const bankname = req.body.bankname;
      const acctnumber  = req.body.acctnumber;
    
  const amount = parseFloat(req.body.amount);

  if (isNaN(amount) || amount <= 0) {
    return res.send('Invalid amount');
  }

  const customer = await Customer.findById(customerId);

  if (!customer) {
    return res.status(404).send('Customer not found');
  }
 // Find the bank in the customer's banks by bankname and acctnumber
    let bank = customer.bank.find(b => b.bankname === bankname && b.acctnumber === acctnumber);

    if (!bank) {
      // Create a new bank in the customer's banks if not found
      bank = { bankname, acctnumber, savings: [], investments: [], balance: 0 };
    //  customer.bank.push(bank);
    }
//customer.bank.forEach(bank1)  => {
    
 // customer.bank.bankname=req.body.bankname;
    
  const selectedProducts = products.filter((p) => productIds.includes(p.name));

  selectedProducts.forEach((product) => {
    const interest = amount * product.interestRate;
    if (product.name === 'Regular Savings') {
      bank.savings.push({ type: 'Savings', amount, interest });
      bank.balance += amount + interest;
    } else {
      bank.investments.push({ type: product.name, amount, interest });
      bank.balance += amount;
    }
  });
     customer.bank.push(bank);
 //   });

  await customer.save();
  res.redirect(`/customers/${customerId}`);
});

// Route to display the form for adding customer and bank details
app.get('/add/customer', (req, res) => {
  res.render('customerDetails');
});

// Route to handle the form submission
app.post('/add', async (req, res) => {
  try {
 //   const { custid, name, bankname, acctnumber, savingsType, savingsAmount, savingsInterest, investmentType, investmentAmount, investmentInterest } = req.body;
      let custid= user.custid;
   //  const customerId = req.params._id;
     const productIds = req.body.products;  
     // let cust_id=req.body.custid;
      const bankname = req.body.bankname;
      const acctnumber  = req.body.acctnumber;
      const amount = parseFloat(req.body.amount);
    // Find the customer by their custid
   //   let customer = await Customer.find({ custid:custid });
     
   let customer = await Customer.findById(customerId);
      console.log("Fetched using customerid : " + customer);
   if (!customer) {
      // Create a new customer in the database if not found
      customer = await Customer.create({ custid, name });
    } 

    // Find the bank in the customer's banks by bankname and acctnumber
    let bank = customer.bank.find(b => b.bankname === bankname && b.acctnumber === acctnumber);
    console.log("bank : " + bank);
    console.log(bankname, acctnumber);
      
    if (!bank) {
      // Create a new bank in the customer's banks if not found
      bank = { bankname, acctnumber, savings: [], investments: [], balance: 0 };
      customer.bank.push(bank);
         console.log("Added bank details : " + bank );
    }
            
    const selectedProducts = products.filter((p) => productIds.includes(p.name));

    selectedProducts.forEach((product) => {
    const interest = amount * product.interestRate;
    if (product.name === 'Regular Savings') {
      bank.savings.push({ type: 'Savings', amount, interest, date: new Date() });
      bank.balance += amount + interest;
         console.log(bank.balance);

        
    } else {
      bank.investments.push({ type: product.name, amount, interest,date: new Date() });
      bank.balance += amount;
    }
        console.log(bank.balance); 
  });
   

    // Save the customer to the database
    await customer.save();
      
    const user = await User.find({custid:user.custid});    
    
       if (!user) {
    return res.status(404).json({ error: "No User Found" });
    }  
    return res.render('custData', { customer, products,user,investmentOptions});
  //  res.redirect('/success');
  } catch (err) {
    res.status(500).send('Error adding data. Please try again later.');
  }
});

// Route to handle logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server started on http://localhost:${port}`);
});
